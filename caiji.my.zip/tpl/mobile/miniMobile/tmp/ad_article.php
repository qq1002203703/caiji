<div class="ad-article p1 radius5 f32 mb2 bg-color6 t-c">
    <a href="/api/open/go?l=<?=\extend\Helper::urlencode('https://888.kliiy.com')?>" class="w12 btn radius5 btn-danger mb2 pt1 pb1" rel="nofollow" target="_blank">登陆</a>
    <a href="/api/open/go?l=<?=\extend\Helper::urlencode('https://888.kliiy.com/index.php?s=/WebPublic/register/code/e90c6596540d69b4d8ac2654ff632d82/plf/link/')?>" class="w12 btn radius5 btn-danger mb2 pt1 pb1" rel="nofollow" target="_blank">注册(1956=1800+7.8%)</a>
    <div class="radius5 color-danger"><img class="w5" src="http://img.iweixinqun.cn/uploads/images/qq.jpg"> 1522216420</div>
</div>