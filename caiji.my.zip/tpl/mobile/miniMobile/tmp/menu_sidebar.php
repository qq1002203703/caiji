<!-- 侧栏导航 -->
<aside class="ui-aside asideRight w40 bg-color-primary mt9 pl1 f34">
    <ul>
        <li><a class="color2" href="/">首页</a></li>
        <li><a class="color2" href="/group/all">小组</a></li>
        <li><a class="color2" href="/user/all">用户中心</a></li>
        <li><a class="color2" href="#">关于1号站</a></li>
    </ul>
</aside>