<header class="ui-header clearfix w75 h9 f46 pl3 pr3 color8 bg-color-primary t-c">
    <div class="ui-header-l fl w5">
        <a class="color8" href="http://<?=$mobile_domain?>"><i class="icon iconfont icon-home_light"></i></a>
    </div>
    <h1 class="ui-header-c fl f32 w56 color8 ml1 mr1"><?=($title??$site_name);?></h1>
    <div class="ui-header-r fr w5">
        <i class="icon iconfont icon-menu"></i>
    </div>
</header>
<div class="yang-warp w75 mt9">