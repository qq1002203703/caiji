{%extend@common/base%}

{%block@title%}
<title><?=$title?>_<?=$site_name?></title>
<meta name="keywords" content="<?=$post['keywords']?>">
<meta name="description" content="<?=$post['excerpt']?>">
{%end%}

{%block@article%}

{%end%}

{%block@javascript%}
<script type="text/javascript" charset="UTF-8">

</script>
{%end%}

