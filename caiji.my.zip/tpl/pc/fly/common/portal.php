{%content@common/base-portal%}
<div class="layui-container">
    <div class="layui-row layui-col-space15">
        {%block@article%}
        <div class="layui-col-md4">
            {%include@common/sidebar%}
        </div>
    </div>
</div>