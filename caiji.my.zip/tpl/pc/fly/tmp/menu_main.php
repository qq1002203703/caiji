<li class="layui-nav-item"><a href="/">首页</a></li>
<li class="layui-nav-item"><a href="/group/all">小组</a></li>
<li class="layui-nav-item"><a href="/user/all">会员中心</a></li>
<li class="layui-nav-item"><a href="#">关于本站</a></li>
<li class="layui-nav-item" style="padding-right: 10px"><a href="/api/open/go?l=<?=\extend\Helper::urlencode('https://www.2hz001.com')?>" class="layui-btn layui-btn-danger layui-btn-sm" rel="nofollow" target="_blank">1号站登陆</a></li>
<li class="layui-nav-item"  style="padding-right: 10px"><a href="/api/open/go?l=<?=\extend\Helper::urlencode('https://www.2hz001.com')?>" class="layui-btn layui-btn-sm" rel="nofollow" target="_blank">2号站登陆</a></li>
<li class="layui-hide-xs layui-nav-item shanshuo">永久防封网址：<span>www.ciaji.my</span></li>