<input class="search-box-input" placeholder="搜片、搜剧">
<span class="search-box-btn"><i class="layui-icon layui-icon-search"></i></span>
<span class="search-key">
    <span>热门&nbsp;:</span>
    <a href="" class="hotwords">主播</a>
    <a href="" class="hotwords">多颂</a>
    <a href="" class="hotwords">韩宝贝</a>
    <a href="" class="hotwords">青草</a>
    <a href="" class="hotwords">敏晶</a>
</span>