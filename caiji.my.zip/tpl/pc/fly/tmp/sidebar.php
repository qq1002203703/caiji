<div class="fly-panel">
    <div class="fly-panel-title">广告</div>
    <div class="fly-panel-main">
        <a href="" target="_blank" class="fly-zanzhu" style="background-color: #393D49;">虚席以待</a>
    </div>
</div>

<div class="fly-panel" id="sidebar-tag">
    <div class="fly-panel-title">最新话题</a></div>
    <div class="fly-panel-main">
        <?php echo listNewestTags(20);?>
    </div>
</div>

<div class="fly-panel fly-link">
    <dt class="fly-panel-title">友情链接</dt>
    <dl class="fly-panel-main">
        <dd><a href="http://www.uuhuihui.com/" target="_blank">uu惠惠</a><dd>
    </dl>
</div>