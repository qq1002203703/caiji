<header class="ui-header clearfix w75 h8 f46 pl3 pr3 color8 bg-color-primary t-c">
    <div class="ui-header-l fl w5">
        <a class="color8" href="<?=$site_url?>"><i class="icon iconfont icon-home_light"></i></a>
    </div>
    <div class="ui-header-c fl f34 w59">
        <a class="color8" href="<?=$site_url?>" title="<?=$site_name?>"><?=$site_name?></a>
    </div>
    <div class="ui-header-r fr w5">
        <i class="icon iconfont icon-menu"></i>
    </div>
</header>
<div class="yang-warp w75 mt8">