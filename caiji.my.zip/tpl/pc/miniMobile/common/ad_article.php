<div class="yang-box p1 radius5 f32 mb2">
    推荐：xxxxxxx<br>
    绝对不黑，绝对提成
</div>