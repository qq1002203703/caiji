<div class="f28 t-c color4 mb2">
    Copyright © 2008-<?=date('Y');?> <?=$site_name?><br>
    <span class="beian"><a class="color4" target="_blank" href="http://beian.miit.gov.cn" rel="nofollow">粤ICP备18096630号-1</a> <script type="text/javascript" src="//js.users.51.la/20078753.js"></script></span>
</div>
</div><!--//end wrap-->
<!-- 返回顶部 -->
<div class="ui-scrollTop radius-o bg-color-primary w10 h10 t-c pt1 f50 color8" onclick="goTop();">
    <i class="icon iconfont icon-fanhuidingbu"></i>
</div>