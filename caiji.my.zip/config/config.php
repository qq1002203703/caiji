<?php 
 return array (
  'template' => 
  array (
    'admin_path' => 'app/common/tpl/layui',
    'admin_cache_path' => 'cache/tpl/admin',
    'view_path' => 'tpl/pc',
    'cache_path' => 'cache/tpl/pc',
    'open_mobile_tpl' => false,
    'mobile_path' => 'tpl/mobile',
    'cache_path_mobile' => 'cache/tpl/mobile',
  ),
  'pwd' => 'Djidksl$$EER4ds58^)UUsshcmO',
  'code_key'=>'O#98287in',
  'kami' => 
  array (
    0 => 
    array (
      'name' => '包月会员卡',
      'value' => '99',
    ),
  ),
);