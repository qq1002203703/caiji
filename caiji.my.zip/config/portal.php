<?php 
 return array (
    'counts_views' => 500,
    'counts_likes' => 10,
    'counts_downloads' => 4,
     'pindao'=>['article'=>'文章','soft'=>'软件','goods'=>'商品','group'=>'小组'],
     'group_category_id'=>23,
     'is_resize'=>true,
     //'thumb'=>'300x200',
     'image_resize'=>'400x530',
     'keyword_link'=>1, //关键词自动锚文本
     'tag_cache'=>0,
     'tag_cache_time'=>3600*5,
     'index_tag'=>'',
     'tag_all_name'=>'网站建设',
     'groupList' =>[1=>'管理员',2=>'管理员',3=>'管理员',4=>'管理员',10=>'普通会员',11=>'日费会员',12=>'月费会员',13=>'年费会员',14=>'永久会员']
);