<?php
//日志相关配置
return array(
    'LOG_TYPE'=>'monolog',#日志驱动
    'LOG_PATH'=>ROOT.'/log/log/'#存储位置
);