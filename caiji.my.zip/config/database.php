<?php
//数据库相关配置
return array(
//-----------------mssqlo数据库配置示例----------------------
	//数据库种类
	'database_type' => 'mysql',
	//数据库名
	'database_name' => 'caiji',
	//服务器地址
	'server' => '127.0.0.1',
	//用户名
	'username' => 'root',
	//密码
	'password' => 'root',
	//端口
	'port' => 3306,
	//字符编码
	'charset' => 'utf8mb4',
	//表前缀
	'prefix' => 'zcm_',
//***-------------sqlite配置示例--------------------------------
    //'database_type' => 'sqlite',
    //'database_file' => 'db/xxxx.rdb'
);