<?php 
 return array (
    'counts_views' => 500,
    'counts_likes' => 10,
    'counts_downloads' => 4,
     //'pindao'=>['article'=>'文章','soft'=>'软件','goods'=>'商品'],
     'thumb'=>'320x200',
     'image_resize'=>'800x500',
     'keyword_link'=>1, //关键词自动锚文本
);