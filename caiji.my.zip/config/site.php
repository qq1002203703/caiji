<?php 
 return array (
  'bbs' => 
  array (
    'comment_perpage' => 20,
  ),
  'city' => NULL,
  'is_realurl' => '1',
  'reg_verify' => '0',
  'sitemap_api' => 
  array (
  ),
  'site_description' => '1号站娱乐平台是一个由无数粉丝组成的大家庭，在这个大家庭可以尽情地交流和学习，方便大家1号站平台对外开放注册，你懂得。',
  'site_keywords' => '1号站平台,1号站娱乐平台',
  'site_name' => '采集系统',
  'site_title' => '1号站平台_1号站娱乐平台_1号站注册家园',
  'site_url' => 'http://www.caiji.my',
  'template' => 'fly',
  'template_mobile' => 'miniMobile',
  'weixinqun_cache' => '0',
  'weixinqun_cache_time' => '18000',
  'ex_domain' => '',
  'fenxiao' => NULL,
  'mobile_domain' => 'm.caiji.my',
  'is_detect_mobile' => '0',
  'tuku' => '',
  'home_module' => '',
);