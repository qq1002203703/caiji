<?php
return array (
    //'counts_views' => 1000,
    //'counts_likes' => 10,
    //'counts_downloads' => 6,
    //'pindao'=>['article'=>'文章','soft'=>'软件','goods'=>'商品'],
    //'thumb'=>'200x200',
    //'image_resize'=>'800x800',
    //'keyword_link'=>1, //关键词自动锚文本
    'tag_cache'=>false,
    'tag_cache_time'=>3600*5,
);