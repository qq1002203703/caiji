<?php 
 return array (
    'counts_views' => 500,
    'counts_likes' => 10,
     //'thumb'=>'200x265',
     'image_resize'=>'400x530',
     'keyword_link'=>1, //关键词自动锚文本
);