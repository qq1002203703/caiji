<?php 
 return array (
  'cc' => 123,
  'ee' => 7898,
);