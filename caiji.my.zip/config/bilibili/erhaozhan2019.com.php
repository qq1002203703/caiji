<?php
return [
    'app_name'=>'erhaozhan2019.com',
    'app_keywords'=>['2号站平台','2号站','2号站娱乐'],
    'search_type'=>'video',
    'search_keyword'=>'php',
    'title_keywords'=>['视频','教程','xx0oo','2号站','2号站平台'],
    //发布
    'title_text'=>['手把手来教你','每天进步一点点','一起来学习吧','实践是最好的学习方法'],
    'fields_filter'=>['content'=>'','comment'=>''],
];